package com.example.apuestas.repository

/*import com.example.apuestas.model.UserRegisterResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("usuario/registro")
    suspend fun registrarUsuario(
        @Body request: UserRegisterRequest
    ): Response<UserRegisterResponse>
}*/
