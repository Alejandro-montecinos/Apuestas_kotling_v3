package com.example.apuestas.model

data class UserRegisterResponse(
    val success: Boolean,
    val message: String
)
