package com.example.apuestas.ui.theme

import androidx.compose.ui.graphics.Color

val NaranjaPrincipal = Color(0xFFFFA726)
val FondoOscuro = Color(0xFF181818)
val GrisClaro = Color(0xFFC5C5C5)
val FondoBoton = Color(0xFFFFA726)
val Blanco = Color.White
val miColor = Color(0xFF300B0B)
